// 织网鉴真 TruthNet - 跨公司对比页
// Phase 3: 多公司对比分析

import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import {
  ArrowLeft,
  AlertTriangle,
  BarChart3,
  Building2,
  Search,
  X,
} from 'lucide-react';
import { truthnetAPI } from '@/lib/api-client';
import type { CompanyRiskSummary, ComparisonsResponseData, RiskLevel } from '@/types/truthnet';
import type { CompanyCandidate } from '@/lib/api-client';

// 对比公司选择器（无 codes 默认入口，审计 P1-2）
function CompanySelector({ onSelect }: { onSelect: (codes: string[]) => void }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<CompanyCandidate[]>([]);
  const [selected, setSelected] = useState<CompanyCandidate[]>([]);
  const [searching, setSearching] = useState(false);
  const MAX_COMPANIES = 5;

  const doSearch = async () => {
    if (!query.trim()) return;
    setSearching(true);
    try {
      const res = await truthnetAPI.searchCompanies(query.trim());
      setResults(res.data?.candidates || []);
    } catch {
      setResults([]);
    } finally {
      setSearching(false);
    }
  };

  const toggle = (c: CompanyCandidate) => {
    setSelected(prev => {
      if (prev.find(x => x.wind_code === c.wind_code)) {
        return prev.filter(x => x.wind_code !== c.wind_code);
      }
      if (prev.length >= MAX_COMPANIES) return prev;
      return [...prev, c];
    });
  };

  return (
    <div className="w-full text-left">
      <div className="flex gap-2">
        <Input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="输入公司名称或代码（如 金牌家居 / 600518）"
          onKeyDown={e => e.key === 'Enter' && doSearch()}
        />
        <Button onClick={doSearch} disabled={searching || !query.trim()}>
          <Search className="h-4 w-4 mr-1" />
          {searching ? '搜索中…' : '搜索'}
        </Button>
      </div>
      {results.length > 0 && (
        <div className="mt-3 border rounded-lg divide-y max-h-64 overflow-auto">
          {results.map(c => {
            const isSelected = selected.some(x => x.wind_code === c.wind_code);
            return (
              <button
                key={c.wind_code}
                onClick={() => toggle(c)}
                className="w-full flex items-center justify-between px-3 py-2 hover:bg-accent text-left"
              >
                <div>
                  <div className="text-sm font-medium">{c.sec_name}</div>
                  <div className="text-xs text-muted-foreground">
                    {c.wind_code} · {c.exchange || '-'}
                  </div>
                </div>
                <Badge variant={isSelected ? 'default' : 'outline'}>
                  {isSelected ? '已选' : '选择'}
                </Badge>
              </button>
            );
          })}
        </div>
      )}
      {selected.length > 0 && (
        <div className="mt-3">
          <p className="text-xs text-muted-foreground mb-1">
            已选 {selected.length}/{MAX_COMPANIES}：
          </p>
          <div className="flex flex-wrap gap-2">
            {selected.map(c => (
              <Badge key={c.wind_code} variant="secondary" className="gap-1 pr-1">
                {c.sec_name}
                <button
                  onClick={() => toggle(c)}
                  className="ml-1 rounded-sm hover:bg-muted p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
          <Button
            className="mt-3 w-full"
            disabled={selected.length < 2}
            onClick={() => onSelect(selected.map(c => c.wind_code))}
          >
            {selected.length < 2 ? '至少选择 2 家公司' : `开始对比（${selected.length} 家）`}
          </Button>
        </div>
      )}
    </div>
  );
}

// v3.3.4 收口复核清单 §5.2-6：choose_comparison_pair 入口——
// 打开选两家界面并预填全部已识别代码（不自动选前两家）
function ChoosePair({ candidateCodes }: { candidateCodes: string[] }) {
  const navigate = useNavigate();
  const [names, setNames] = useState<Record<string, string>>({});
  const [selected, setSelected] = useState<string[]>([]);
  const key = candidateCodes.join(',');

  useEffect(() => {
    let cancelled = false;
    candidateCodes.forEach(code => {
      truthnetAPI
        .getCompanyProfile(code)
        .then(res => {
          if (!cancelled && res.data?.sec_name) {
            setNames(prev => ({ ...prev, [code]: res.data!.sec_name! }));
          }
        })
        .catch(() => undefined);
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const toggle = (code: string) => {
    // 收口复核审查 P2b：choose_comparison_pair 语义 = 恰好选择两家
    // （已选 2 家时不得继续增加，与文案「选择两家对比」一致）
    setSelected(prev =>
      prev.includes(code)
        ? prev.filter(c => c !== code)
        : prev.length >= 2
          ? prev
          : [...prev, code],
    );
  };

  return (
    <div className="flex-1 flex items-center justify-center p-6">
      <div className="w-full max-w-xl">
        <div className="text-center mb-6">
          <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <h2 className="text-lg font-medium">从已识别公司中选择两家对比</h2>
          <p className="text-sm text-muted-foreground mt-1">
            对话一次仅支持两家数值比较；以下为已识别的全部公司，请勾选其中两家
          </p>
        </div>
        <div className="flex flex-wrap gap-2 justify-center">
          {candidateCodes.map(code => {
            const isSelected = selected.includes(code);
            const disabled = selected.length >= 2 && !isSelected;
            return (
              <button
                key={code}
                onClick={() => toggle(code)}
                disabled={disabled}
                className={cn(
                  'flex items-center gap-2 rounded-lg border px-3 py-2 text-sm transition-colors',
                  isSelected
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:bg-muted/50',
                  disabled && 'opacity-50 cursor-not-allowed',
                )}
              >
                <span className="font-medium">{names[code] || code}</span>
                <span className="text-xs text-muted-foreground">{code}</span>
                <Badge variant={isSelected ? 'default' : 'outline'}>
                  {isSelected ? '已选' : '选择'}
                </Badge>
              </button>
            );
          })}
        </div>
        <Button
          className="mt-6 w-full"
          disabled={selected.length < 2}
          onClick={() => navigate(`/compare?codes=${selected.join(',')}`)}
        >
          {selected.length < 2
            ? `请选择 2 家公司（已选 ${selected.length}）`
            : `开始对比（${selected.length} 家）`}
        </Button>
      </div>
    </div>
  );
}

// 风险等级配置
const riskLevelConfig: Record<RiskLevel, { label: string; color: string }> = {
  red: { label: '高危', color: 'bg-red-500 text-white' },
  orange: { label: '中高危', color: 'bg-orange-500 text-white' },
  yellow: { label: '中等', color: 'bg-yellow-500 text-white' },
  blue: { label: '低风险', color: 'bg-blue-500 text-white' },
  green: { label: '正常', color: 'bg-green-500 text-white' },
  unknown: { label: '未知', color: 'bg-gray-500 text-white' },
};

export default function ComparePage() {
  useDocumentTitle('跨公司对比');
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [companies, setCompanies] = useState<CompanyRiskSummary[]>([]);
  const [comparisonData, setComparisonData] = useState<ComparisonsResponseData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [industryUnavailable, setIndustryUnavailable] = useState(false);

  // v3.3.4 收口复核清单 §5.3：读取 codes + scope（默认 full）；
  // choose_comparison_pair 入口用 candidates 参数（预填全部代码）
  const codesParam = [
    ...new Set(
      (searchParams.get('codes') || '')
        .split(',')
        .map(c => c.trim())
        .filter(Boolean),
    ),
  ].slice(0, 5);
  const scope = searchParams.get('scope') ?? 'full';
  const candidateCodes = [
    ...new Set(
      (searchParams.get('candidates') || '')
        .split(',')
        .map(c => c.trim())
        .filter(Boolean),
    ),
  ].slice(0, 5);

  useEffect(() => {
    const loadCompanies = async () => {
      setLoading(true);
      setError(null);
      setIndustryUnavailable(false);

      // 选两家入口：不自动查询，等待用户在预填列表中勾选
      if (candidateCodes.length > 0) {
        setLoading(false);
        return;
      }

      if (codesParam.length === 0) {
        setError('请选择要对比的公司');
        setLoading(false);
        return;
      }

      // 行业分位数据源未接入（清单 §5.3）：诚实降级，不得把普通
      // 对比结果伪装成行业对比
      if (scope === 'industry') {
        setIndustryUnavailable(true);
        setLoading(false);
        return;
      }

      try {
        // 调用对比 API
        const response = await truthnetAPI.compareCompanies(codesParam);
        const data = response.data;
        if (!data) {
          setError('无对比数据');
          setLoading(false);
          return;
        }
        setCompanies(data.companies);
        setComparisonData(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : '加载失败');
      } finally {
        setLoading(false);
      }
    };

    loadCompanies();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  // 获取风险等级样式
  const getRiskLevelStyle = (level: string) => {
    return riskLevelConfig[level as RiskLevel]?.color || 'bg-gray-500 text-white';
  };

  if (loading) {
    return (
      <div className="h-full flex flex-col bg-background">
        <header className="border-b px-6 py-4 flex items-center gap-4">
          <Skeleton className="h-8 w-8" />
          <Skeleton className="h-6 w-32" />
        </header>
        <div className="flex-1 p-6 space-y-4">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  // v3.3.4 收口复核清单 §5.2-6：choose_comparison_pair 选两家入口
  if (candidateCodes.length > 0) {
    return (
      <div className="h-full flex flex-col bg-background">
        <header className="border-b px-6 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-lg font-medium">跨公司对比</h1>
        </header>
        <ChoosePair candidateCodes={candidateCodes} />
      </div>
    );
  }

  // v3.3.4 收口复核清单 §5.3：行业分位数据源未接入 → 诚实降级，
  // 明确不可用，不把普通对比结果伪装成行业对比
  if (industryUnavailable) {
    return (
      <div className="h-full flex flex-col bg-background">
        <header className="border-b px-6 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-lg font-medium">跨公司对比 · 行业对比</h1>
        </header>
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="text-center max-w-md">
            <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-lg font-medium">行业分位暂未接入</h2>
            <p className="text-sm text-muted-foreground mt-2">
              行业分位/行业基准数据源尚未接入，暂无法展示行业对比结果。
              可先查看这些公司的普通完整对比。
            </p>
            <Button
              className="mt-4"
              onClick={() => navigate(`/compare?codes=${codesParam.join(',')}`)}
            >
              查看普通完整对比
            </Button>
            <Button variant="outline" className="mt-4 ml-2" onClick={() => navigate(-1)}>
              返回
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    // 无 codes 默认入口 → 内置选股器（审计 P1-2，替代原"请选择公司"错误页）
    const showSelector = error === '请选择要对比的公司';
    return (
      <div className="h-full flex flex-col bg-background">
        <header className="border-b px-6 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-lg font-medium">跨公司对比</h1>
        </header>
        <div className="flex-1 flex items-center justify-center p-6">
          {showSelector ? (
            <div className="w-full max-w-xl">
              <div className="text-center mb-6">
                <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <h2 className="text-lg font-medium">选择要对比的公司</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  支持 2~5 家，搜索后勾选即可
                </p>
              </div>
              <CompanySelector
                onSelect={codes => navigate(`/compare?codes=${codes.join(',')}`)}
              />
            </div>
          ) : (
            <div className="text-center">
              <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
              <p className="text-muted-foreground">{error}</p>
              <Button variant="outline" className="mt-4" onClick={() => navigate(-1)}>
                返回
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (companies.length === 0) {
    return (
      <div className="h-full flex flex-col bg-background">
        <header className="border-b px-6 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-lg font-medium">跨公司对比</h1>
        </header>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">未找到公司数据</p>
            <Button variant="outline" className="mt-4" onClick={() => navigate(-1)}>
              返回
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* 头部 */}
      <header className="border-b px-6 py-4 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-lg font-medium">跨公司对比</h1>
        <Badge variant="secondary">
          {companies.length} 家公司
        </Badge>
      </header>

      {/* 内容区 */}
      <div className="flex-1 overflow-auto p-6">
        <ScrollArea className="h-full">
          <div className="space-y-6">
            {/* 公司概览 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  公司概览
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  {companies.map((company) => (
                    <div key={company.wind_code} className="p-4 rounded-lg border bg-card">
                      <div className="font-medium">{company.sec_name}</div>
                      <div className="text-xs text-muted-foreground mb-2">
                        {company.wind_code}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={cn('text-xs', getRiskLevelStyle(company.risk_level))}>
                          {riskLevelConfig[company.risk_level as RiskLevel]?.label}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {company.industry_l1}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 指标对比 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  指标对比
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(comparisonData?.indicators && comparisonData.indicators.length > 0 ? comparisonData.indicators : comparisonData?.companies?.[0] ? [
                    { indicator: 'risk_level', label: '风险等级', companies: comparisonData.companies.map(c => ({ wind_code: c.wind_code, sec_name: c.sec_name, value: 0, unit: '', severity: c.risk_level, status: '' })) },
                    { indicator: 'overall_score', label: '综合评分', companies: comparisonData.companies.map(c => ({ wind_code: c.wind_code, sec_name: c.sec_name, value: c.overall_score, unit: '分', severity: '', status: '' })) },
                    { indicator: 'triggered_rules', label: '触发规则数', companies: comparisonData.companies.map(c => ({ wind_code: c.wind_code, sec_name: c.sec_name, value: c.triggered_rules.length, unit: '条', severity: '', status: '' })) },
                    { indicator: 'coverage', label: '数据覆盖率', companies: comparisonData.companies.map(c => ({ wind_code: c.wind_code, sec_name: c.sec_name, value: c.coverage, unit: '%', severity: '', status: '' })) },
                    { indicator: 'pattern_matches', label: '模式匹配', companies: comparisonData.companies.map(c => ({ wind_code: c.wind_code, sec_name: c.sec_name, value: c.pattern_matches?.length ?? 0, unit: '个', severity: '', status: '' })) },
                  ] : []).map((indicator) => {
                    return (
                      <div key={indicator.indicator} className="space-y-2">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <BarChart3 className="h-4 w-4 text-muted-foreground" />
                          {indicator.label}
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          {indicator.companies.map((ci) => {
                            const isRisk = indicator.indicator === 'risk_level';
                            const displayValue = indicator.indicator === 'coverage'
                              ? `${((ci.value ?? 0) * 100).toFixed(0)}%`
                              : ci.value != null ? `${ci.value}${ci.unit || ''}` : '-';
                            return (
                              <div
                                key={ci.wind_code}
                                className="p-3 rounded-lg border bg-card text-center"
                              >
                                {isRisk ? (
                                  <Badge className={cn('text-xs', getRiskLevelStyle(ci.severity || String(ci.value ?? '')))}>
                                    {riskLevelConfig[ci.severity as RiskLevel]?.label || ci.severity || String(ci.value ?? '-')}
                                  </Badge>
                                ) : (
                                  <span className="text-lg font-medium">
                                    {displayValue}
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* 触发规则对比 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  触发规则对比
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {companies.map((company) => (
                    <div key={company.wind_code} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{company.sec_name}</span>
                        <Badge variant="secondary" className="text-xs">
                          {company.triggered_rules.length} 条规则
                        </Badge>
                      </div>
                      <div className="space-y-1">
                        {company.triggered_rules.slice(0, 3).map((rule, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between text-xs p-2 rounded bg-muted/50"
                          >
                            <span>{rule}</span>
                          </div>
                        ))}
                        {company.triggered_rules.length > 3 && (
                          <div className="text-xs text-muted-foreground text-center">
                            +{company.triggered_rules.length - 3} 条更多规则
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 免责声明 */}
            <div className="text-center text-xs text-muted-foreground py-4">
              以上数据仅供参考，不构成投资建议
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
