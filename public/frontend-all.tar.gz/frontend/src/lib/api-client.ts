/**
 * TruthNet 织网鉴真 — 前端 API 客户端
 *
 * 对接后端 13 个 REST 端点 + WebSocket
 * 响应格式: V12 { data, meta, warnings } 信封
 *
 * 开发模式通过 Vite proxy 转发到 http://localhost:8000
 */

// ---------------------------------------------------------------------------
// V12 统一响应格式
// ---------------------------------------------------------------------------

export interface V12Meta {
  request_id: string;
  trace_id: string;
  schema_version: string;
  generated_at: string;
  data_as_of: string;
  dataset_version: string;
  rule_set_version: string;
  graph_version: string;
}

export interface V12Response<T> {
  data: T | null;
  meta: V12Meta;
  warnings: string[];  // 后端返回字符串数组
}

// ---------------------------------------------------------------------------
// 错误格式 (RFC 9457 ProblemDetail)
// ---------------------------------------------------------------------------

export interface ProblemDetail {
  type: string;
  title: string;
  status: number;
  detail: string;
  instance?: string;
}

// ---------------------------------------------------------------------------
// 基础请求函数
// ---------------------------------------------------------------------------

const API_BASE = '/api/v1';

async function request<T>(
  method: string,
  path: string,
  options?: RequestInit & { params?: Record<string, string | number | boolean | undefined> }
): Promise<V12Response<T>> {
  const { params, ...fetchOptions } = options || {};

  let url = `${API_BASE}${path}`;
  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) searchParams.set(key, String(value));
    });
    const query = searchParams.toString();
    if (query) url += `?${query}`;
  }

  const res = await fetch(url, {
    ...fetchOptions,
    method,
    headers: {
      'Content-Type': 'application/json',
      ...fetchOptions.headers,
    },
  });

  if (!res.ok) {
    const error: ProblemDetail = await res.json().catch(() => ({
      type: 'about:blank',
      title: 'Network Error',
      status: res.status,
      detail: res.statusText,
    }));
    throw new Error(`${error.title}: ${error.detail}`);
  }

  return res.json();
}

// ---------------------------------------------------------------------------
// 类型定义 (对齐后端 Schema)
// ---------------------------------------------------------------------------

// 公司
export interface Company {
  wind_code: string;
  sec_name: string;
  entity_id?: string;
  company_type?: string;
  industry_l1?: string;
  industry_l2?: string;
  province?: string;
  list_date?: string;
}

// 会话
export interface Session {
  id: string;
  title: string;
  company_code: string;
  company_name: string;
  created_at: string;
  updated_at: string;
  message_count: number;
  risk_level?: string;
}

// 消息
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
  evidence_ids?: string[];
  is_streaming?: boolean;
}

// 面板状态
export type PanelState = 'idle' | 'loading' | 'ready' | 'error';

// 面板数据
export interface PanelData {
  risk_level?: 'low' | 'medium' | 'high';
  triggered_rules?: string[];
  key_metrics?: Record<string, number>;
}

// 股权穿透节点 (对齐后端 EquityNodeSchema)
export interface EquityNode {
  entity_id: string;
  wind_code: string | null;
  name: string;
  node_type: 'company' | 'person' | 'fund';
  match_confidence: number;
  mock: boolean;
  depth?: number;
}

// 股权穿透边 (对齐后端 EquityEdgeSchema)
export interface EquityEdge {
  source_id: string;
  target_id: string;
  ownership: number;
  relation: string;
  path_depth: number;
}

// 股权穿透数据 (对齐后端 EquityResponseData)
export interface EquityData {
  wind_code: string;
  sec_name: string;
  nodes: EquityNode[];
  edges: EquityEdge[];
  paths: string[][];
  as_of: string | null;
  graph_backend: string;
  resolved_from_mysql: boolean;
  entity_count: number;
}

// 财务规则项 (对齐后端 FinanceRuleItem)
export interface FinanceRuleItem {
  rule_id: string;
  rule_name: string;
  triggered: boolean;
  risk_level: 'low' | 'medium' | 'high';
  current_value: number | null;
  threshold: number | null;
  industry_percentile: number | null;
  reasoning: string;
}

// 财务分析数据 (对齐后端 FinanceResponseData)
export interface FinanceData {
  wind_code: string;
  sec_name: string;
  risk_level: string;
  rules: FinanceRuleItem[];
  industry_benchmark: string | null;
  data_quality: string;
  warnings: string[];
}

// 舆情事件 (对齐后端 EventItem)
export interface EventItem {
  event_id: string;
  title: string;
  event_type: string;
  severity: 'low' | 'medium' | 'high';
  source: string;
  publish_time: string;
  summary: string;
  related_companies: string[];
}

// 事件簇 (对齐后端 EventCluster)
export interface EventCluster {
  cluster_id: string;
  title: string;
  event_type: string;
  severity: 'low' | 'medium' | 'high';
  event_count: number;
  first_seen: string;
  last_seen: string;
  events: EventItem[];
}

// 舆情数据 (对齐后端 EventResponseData)
export interface EventsData {
  wind_code: string;
  sec_name: string;
  sentiment_summary: string;
  event_clusters: EventCluster[];
  timeline: EventItem[];
  rating_changes: unknown[];
  keyword_summary: Record<string, number>;
  warnings: string[];
}

// 模式匹配 (对齐后端 PatternMatch)
export interface PatternMatch {
  pattern_id: string;
  pattern_name: string;
  confidence: number;
  reasoning: string;
}

// 缓解因素 (对齐后端 MitigatingFactor)
export interface MitigatingFactor {
  factor: string;
  category: string;
  weight: number;
}

// 数据覆盖率 (对齐后端 DataCoverage)
export interface DataCoverage {
  finance: number;
  equity: number;
  events: number;
  benchmarks: number;
  coverage_ratio: number;
}

// 子评分 (对齐后端 SubScore)
export interface SubScore {
  label: string;
  weight: number;
  contribution: number;
  status: string;
  warning: string | null;
}

// 风险证据 (对齐后端 RiskEvidence)
export interface RiskEvidence {
  evidence_id: string;
  source_type: string;
  claim_ids: string[];
  summary: string;
}

// 风险数据 (对齐后端 RiskResponseData)
export interface RiskData {
  wind_code: string;
  sec_name: string;
  risk_level: string;
  risk_score: number;
  pattern_matches: PatternMatch[];
  mitigating_factors: MitigatingFactor[];
  data_coverage: DataCoverage;
  sub_scores: SubScore[];
  evidence: RiskEvidence[];
  warnings: string[];
}

// 行业百分位 (对齐后端 IndustryPercentile)
export interface IndustryPercentile {
  indicator: string;
  value: number;
  percentile: number;
  peer_count: number;
}

// 行业基准数据 (对齐后端 BenchmarkResponseData)
export interface BenchmarkData {
  wind_code: string;
  sec_name: string;
  industry_l1: string;
  period: string;
  percentiles: IndustryPercentile[];
  peer_count: number;
  warnings: string[];
}

// 对比结果 (对齐后端 ComparisonResult)
export interface ComparisonResult {
  wind_code: string;
  sec_name: string;
  risk_level: string;
  risk_score: number;
  indicators: Record<string, number | null>;
}

// 对比数据 (对齐后端 ComparisonResponseData)
export interface ComparisonData {
  period: string;
  results: ComparisonResult[];
  warnings: string[];
}

// Chat 响应 (对齐后端 ChatResponseV1)
export interface ChatResponse {
  session_id: string;
  answer: string;
  answer_type: string;
  evidence_ids: string[];
  trace_id: string;
  follow_ups: string[];
  warnings: string[];
}

// ---------------------------------------------------------------------------
// API 客户端
// ---------------------------------------------------------------------------

export const truthnetAPI = {
  // 健康检查
  health: () => request<{ status: string }>('GET', '/health'),

  // 公司搜索: GET /api/v1/companies?query=xxx
  searchCompanies: (query: string) =>
    request<Company[]>('GET', '/companies', { params: { query } }),

  // 公司详情: GET /api/v1/companies/{code}
  getCompanyProfile: (code: string) =>
    request<Company>('GET', `/companies/${encodeURIComponent(code)}`),

  // 财务分析: GET /api/v1/companies/{code}/finance
  getFinance: (code: string) =>
    request<FinanceData>('GET', `/companies/${encodeURIComponent(code)}/finance`),

  // 舆情事件: GET /api/v1/companies/{code}/events
  getEvents: (code: string) =>
    request<EventsData>('GET', `/companies/${encodeURIComponent(code)}/events`),

  // 股权穿透: GET /api/v1/companies/{code}/equity
  getEquity: (code: string, depth: number = 5) =>
    request<EquityData>('GET', `/companies/${encodeURIComponent(code)}/equity`, {
      params: { depth },
    }),

  // 风险评估: GET /api/v1/companies/{code}/risk
  getRisk: (code: string) =>
    request<RiskData>('GET', `/companies/${encodeURIComponent(code)}/risk`),

  // 行业基准: GET /api/v1/companies/{code}/benchmarks
  getBenchmarks: (code: string) =>
    request<BenchmarkData>('GET', `/companies/${encodeURIComponent(code)}/benchmarks`),

  // 跨公司对比: POST /api/v1/comparisons
  compareCompanies: (companyCodes: string[], period?: string, indicators?: string[]) =>
    request<ComparisonData>('POST', '/comparisons', {
      body: JSON.stringify({
        company_codes: companyCodes,
        period: period || '2023',
        indicators: indicators || [],
      }),
    }),

  // 会话列表: GET /api/v1/sessions
  getSessions: () => request<Session[]>('GET', '/sessions'),

  // 创建会话: POST /api/v1/sessions
  createSession: (title: string = '新对话') =>
    request<Session>('POST', '/sessions', {
      body: JSON.stringify({ title }),
    }),

  // 删除会话: DELETE /api/v1/sessions/{sessionId}
  deleteSession: (sessionId: string) =>
    request<{ ok: boolean }>('DELETE', `/sessions/${sessionId}`),

  // 发送消息: POST /api/v1/chat
  sendChatMessage: (question: string, sessionId?: string) =>
    request<ChatResponse>('POST', '/chat', {
      body: JSON.stringify({
        question,
        session_id: sessionId,
      }),
    }),
};

// ---------------------------------------------------------------------------
// WebSocket 客户端
// ---------------------------------------------------------------------------

export interface WSMessage {
  type: 'thinking' | 'text_chunk' | 'structured_data' | 'evidence' | 'done' | 'error';
  content?: string;
  data?: unknown;
}

export const wsClient = {
  create: (sessionId: string, onMessage: (msg: WSMessage) => void) => {
    const wsUrl = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/api/v1/chat/ws?session_id=${sessionId}`;
    const ws = new WebSocket(wsUrl);

    ws.onmessage = (event) => {
      try {
        const msg: WSMessage = JSON.parse(event.data);
        onMessage(msg);
      } catch (e) {
        console.error('WebSocket message parse error:', e);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      onMessage({ type: 'error', content: '连接错误' });
    };

    ws.onclose = () => {
      onMessage({ type: 'done' });
    };

    return {
      send: (question: string) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ question }));
        }
      },
      close: () => ws.close(),
    };
  },
};

// ---------------------------------------------------------------------------
// 兼容旧接口
// ---------------------------------------------------------------------------

export const apiClient = {
  getSessions: truthnetAPI.getSessions,
  createSession: truthnetAPI.createSession,
  deleteSession: truthnetAPI.deleteSession,
  sendChatMessage: truthnetAPI.sendChatMessage,
};

export default truthnetAPI;
