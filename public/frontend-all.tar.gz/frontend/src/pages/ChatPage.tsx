// 织网鉴真 TruthNet - 对话主页
// T1: 三栏布局（会话侧边栏 + 对话区 + 分析面板）
// Phase 1: 对接真实 API

import { useState, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { SessionSidebar } from '@/components/truthnet/SessionSidebar';
import { ChatInterface } from '@/components/truthnet/ChatInterface';
import { AnalysisPanel } from '@/components/truthnet/AnalysisPanel';
import { apiClient, wsClient } from '@/lib/api-client';
import type { Session, Message, PanelData, PanelState, ChatResponse } from '@/types/truthnet';
import { PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ChatPage() {
  // 状态管理
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [panelData, setPanelData] = useState<PanelData | null>(null);
  const [panelState, setPanelState] = useState<PanelState>('empty');
  const [panelCollapsed, setPanelCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // 当前会话
  const currentSession = sessions.find(s => s.id === currentSessionId);

  // 加载会话列表
  useEffect(() => {
    const loadSessions = async () => {
      try {
        const response = await apiClient.getSessions();
        setSessions(response.data.map(s => ({
          id: s.id,
          title: s.title,
          company_code: s.company_code || '',
          company_name: s.company_name || '',
          created_at: s.created_at,
          updated_at: s.updated_at,
          message_count: s.message_count,
        })));
        if (response.data.length > 0 && !currentSessionId) {
          setCurrentSessionId(response.data[0].id);
        }
      } catch (error) {
        console.error('Failed to load sessions:', error);
      }
    };
    loadSessions();
  }, []);

  // 加载会话消息
  useEffect(() => {
    if (!currentSessionId) return;
    
    // 会话消息通过 WebSocket 实时获取，这里不需要额外加载
    setMessages([]);
    setPanelState('done');
  }, [currentSessionId]);

  // 创建新会话
  const handleNewSession = async () => {
    try {
      const response = await apiClient.createSession({
        title: '新对话',
      });
      const newSession: Session = {
        id: response.data.id,
        title: '新对话',
        company_code: '',
        company_name: '',
        created_at: response.data.created_at,
        updated_at: response.data.updated_at,
        message_count: 0,
      };
      setSessions([newSession, ...sessions]);
      setCurrentSessionId(newSession.id);
      setMessages([]);
      setPanelData(null);
      setPanelState('empty');
    } catch (error) {
      console.error('Failed to create session:', error);
    }
  };

  // 切换会话
  const handleSelectSession = (sessionId: string) => {
    setCurrentSessionId(sessionId);
  };

  // 删除会话
  const handleDeleteSession = async (sessionId: string) => {
    try {
      await apiClient.deleteSession(sessionId);
      const newSessions = sessions.filter(s => s.id !== sessionId);
      setSessions(newSessions);
      if (currentSessionId === sessionId) {
        setCurrentSessionId(newSessions[0]?.id || '');
        setMessages([]);
        setPanelData(null);
        setPanelState('empty');
      }
    } catch (error) {
      console.error('Failed to delete session:', error);
    }
  };

  // 处理 WebSocket 事件
  const handleWSEvent = useCallback((event: { type: string; data: unknown }) => {
    switch (event.type) {
      case 'turn.accepted':
        setPanelState('thinking');
        break;
      case 'module.started':
        // 更新思考进度
        break;
      case 'module.completed':
        // 更新模块完成状态
        break;
      case 'answer.delta': {
        const delta = event.data as { content: string };
        setMessages(prev => {
          const lastMsg = prev[prev.length - 1];
          if (lastMsg && lastMsg.role === 'assistant') {
            return [...prev.slice(0, -1), {
              ...lastMsg,
              content: lastMsg.content + delta.content,
            }];
          }
          return [...prev, {
            id: `msg-${Date.now()}`,
            session_id: currentSessionId,
            role: 'assistant',
            content: delta.content,
            created_at: new Date().toISOString(),
          }];
        });
        setPanelState('streaming');
        break;
      }
      case 'artifact.upsert': {
        const artifact = event.data as { artifact_type: string; payload: unknown };
        if (artifact.artifact_type === 'panel_data') {
          setPanelData(artifact.payload as PanelData);
        }
        break;
      }
      case 'turn.completed': {
        const result = event.data as { turn_id: string; follow_ups: string[] };
        // 不再需要更新 is_streaming，因为 Message 类型没有这个属性
        setPanelState('done');
        setIsLoading(false);
        break;
      }
      case 'error': {
        const error = event.data as { code: string; message: string };
        console.error('WebSocket error:', error);
        setPanelState('error');
        setIsLoading(false);
        break;
      }
    }
  }, [currentSessionId]);

  // 连接 WebSocket
  useEffect(() => {
    if (!currentSessionId) return;
    
    wsClient.connect();
    wsClient.onEvent(handleWSEvent);
    
    return () => {
      wsClient.offEvent(handleWSEvent);
    };
  }, [currentSessionId, handleWSEvent]);

  // 发送消息
  const handleSendMessage = async (content: string) => {
    if (!currentSessionId || isLoading) return;
    
    // 添加用户消息
    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      session_id: currentSessionId,
      role: 'user',
      content,
      created_at: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setPanelState('thinking');

    try {
      // 通过 WebSocket 发送消息
      wsClient.send({
        type: 'turn.submit',
        data: {
          session_id: currentSessionId,
          user_input: content,
          client_request_id: `req-${Date.now()}`,
        },
      });
    } catch (error) {
      console.error('Failed to send message:', error);
      setIsLoading(false);
      setPanelState('error');
    }
  };

  // 点击追问建议
  const handleFollowUp = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  return (
    <div className="flex h-[calc(100vh-64px)] overflow-hidden">
      {/* 左侧：会话侧边栏 */}
      <SessionSidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
      />

      {/* 中间：对话区 */}
      <div className="flex-1 flex flex-col min-w-0">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
        />
      </div>

      {/* 右侧：分析面板 */}
      <div
        className={cn(
          'transition-all duration-300 border-l border-border',
          panelCollapsed ? 'w-0 overflow-hidden' : 'w-[380px]'
        )}
      >
        {!panelCollapsed && (
          <AnalysisPanel
            state={panelState}
            data={panelData}
            company={currentSession ? {
              code: currentSession.company_code,
              name: currentSession.company_name,
            } : undefined}
            onFollowUp={handleFollowUp}
          />
        )}
      </div>

      {/* 面板折叠/展开按钮 */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-20 z-10"
        onClick={() => setPanelCollapsed(!panelCollapsed)}
      >
        {panelCollapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
      </Button>
    </div>
  );
}
