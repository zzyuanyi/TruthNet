/**
 * TruthNet 织网鉴真 — 前端 API 客户端
 *
 * 对接后端 13 个 REST 端点 + WebSocket
 * 响应格式: V12 { data, meta, warnings } 信封
 *
 * 开发模式通过 Vite proxy 转发到 http://localhost:8000
 */

// ---------------------------------------------------------------------------
// V12 统一响应格式
// ---------------------------------------------------------------------------

export interface V12Meta {
  request_id: string;
  trace_id: string;
  schema_version: string;
  generated_at: string;
  data_as_of: string;
  dataset_version: string;
  rule_set_version: string;
  graph_version: string;
}

export interface V12Warning {
  code: string;
  message: string;
  module?: string;
  recoverable: boolean;
}

export interface V12Response<T> {
  data: T | null;
  meta: V12Meta;
  warnings: V12Warning[];
}

// ---------------------------------------------------------------------------
// 错误格式 (RFC 9457 ProblemDetail)
// ---------------------------------------------------------------------------

export interface ProblemDetail {
  type: string;
  title: string;
  status: number;
  detail: string;
  instance?: string;
}

// ---------------------------------------------------------------------------
// 基础请求函数
// ---------------------------------------------------------------------------

const API_BASE = '/api/v1';

async function request<T>(
  method: string,
  path: string,
  options?: RequestInit & { params?: Record<string, string | number | undefined> }
): Promise<V12Response<T>> {
  const { params, ...fetchOptions } = options || {};

  let url = `${API_BASE}${path}`;
  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) searchParams.set(key, String(value));
    });
    const query = searchParams.toString();
    if (query) url += `?${query}`;
  }

  const res = await fetch(url, {
    ...fetchOptions,
    method,
    headers: {
      'Content-Type': 'application/json',
      ...fetchOptions.headers,
    },
  });

  if (!res.ok) {
    const error: ProblemDetail = await res.json().catch(() => ({
      type: 'about:blank',
      title: 'Network Error',
      status: res.status,
      detail: res.statusText,
    }));
    throw new Error(`${error.title}: ${error.detail}`);
  }

  return res.json();
}

// ---------------------------------------------------------------------------
// 类型定义
// ---------------------------------------------------------------------------

// 公司
export interface Company {
  code: string;
  name: string;
  industry: string;
  market: string;
}

// 会话
export interface Session {
  id: string;
  title: string;
  company_code: string;
  company_name: string;
  created_at: string;
  updated_at: string;
  message_count: number;
  risk_level?: RiskLevel;
}

// 消息
export interface Message {
  id: string;
  session_id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
  thinking?: string;
  structured_data?: PanelData;
  follow_ups?: string[];
  sources?: EvidenceSource[];
}

// 风险等级
export type RiskLevel = 'red' | 'orange' | 'yellow' | 'blue' | 'green';

// 面板数据
export interface PanelData {
  risk_level: RiskLevel;
  triggered_rules: TriggeredRule[];
  key_metrics: KeyMetric[];
  company?: Company;
}

export interface TriggeredRule {
  id: string;
  name: string;
  current_value: string;
  threshold: string;
  industry_percentile: number;
  severity: 'high' | 'medium' | 'low';
}

export interface KeyMetric {
  name: string;
  value: string;
  change?: string;
  risk_indicator?: RiskLevel;
  industry_benchmark?: string;
}

// 证据
export interface EvidenceSource {
  evidence_id: string;
  source: string;
  field: string;
  value: string;
  source_type: string;
  source_record_id?: string;
  source_title?: string;
  field_path?: string;
  period?: string;
  unit?: string;
  source_uri?: string;
  dataset_version?: string;
}

// 财务规则
export interface FinanceRule {
  rule_id: string;
  rule_name: string;
  status: 'triggered' | 'not_triggered' | 'insufficient_data' | 'error';
  severity: RiskLevel;
  current: Record<string, { value: number; unit: string }>;
  history: Array<Record<string, number | string>>;
  industry: { p50: number; p75: number; p90: number };
  explanation: string;
  evidence_ids: string[];
}

// 事件
export interface EventCluster {
  event_cluster_id: string;
  topic: string;
  event_count: number;
  start_date: string;
  end_date: string;
  sentiment: 'positive' | 'negative' | 'neutral' | 'mixed';
  summary: string;
  sources: Array<{
    source_type: string;
    title: string;
    published_at: string;
  }>;
}

export interface SentimentSummary {
  positive_count: number;
  negative_count: number;
  neutral_count: number;
  total_count: number;
  negative_ratio: number;
}

export interface TimelineEvent {
  date: string;
  title: string;
  source_type: string;
  sentiment: string;
  summary: string;
}

// 风险评分
export interface RiskScore {
  overall: number;
  financial: number;
  ownership: number;
  sentiment: number;
}

export interface RiskAssessment {
  overall_score: number;
  risk_level: RiskLevel;
  sub_scores: Array<{ dimension: string; score: number }>;
  pattern_matches: string[];
  mitigating_factors: string[];
  data_coverage: number;
  evidence: EvidenceSource[];
}

// 股权穿透
export interface EquityNode {
  id: string;
  name: string;
  entity_type: 'company' | 'person' | 'fund';
  ownership_pct?: number;
  risk_level?: RiskLevel;
  is_target?: boolean;
  source_system?: string;
}

export interface EquityEdge {
  source: string;
  target: string;
  relation_type: string;
  ownership_pct: number;
  relationship_id?: string;
}

export interface EquityData {
  nodes: EquityNode[];
  edges: EquityEdge[];
}

// 行业基准
export interface IndustryBenchmark {
  metric: string;
  p05: number;
  p25: number;
  p50: number;
  p75: number;
  p95: number;
  company_value: number;
  company_percentile: number;
}

// 对比
export interface ComparisonIndicator {
  indicator: string;
  label: string;
  companies: Array<{
    wind_code: string;
    sec_name: string;
    value: number;
    unit: string;
    severity: RiskLevel;
    status: string;
  }>;
}

export interface ComparisonCompany {
  wind_code: string;
  sec_name: string;
  risk_level: RiskLevel;
  overall_score: number;
  triggered_rules: string[];
  pattern_matches: string[];
  coverage: number;
  evidence_ids: string[];
}

export interface ComparisonData {
  period: string;
  indicators: ComparisonIndicator[];
  companies: ComparisonCompany[];
}

// Chat 响应
export interface ChatResponse {
  answer: string;
  evidence: EvidenceSource[];
  graph: EquityData;
  timeline: TimelineEvent[];
  risk_score: RiskScore;
  warnings: V12Warning[];
  missing_modules: string[];
}

// ---------------------------------------------------------------------------
// API 端点
// ---------------------------------------------------------------------------

// 1. 健康检查
export async function healthCheck(): Promise<V12Response<{ status: string }>> {
  return request('GET', '/healthz');
}

// 2. 会话管理
export async function getSessions(): Promise<V12Response<Session[]>> {
  return request('GET', '/sessions');
}

export async function createSession(data: {
  title: string;
  company_code: string;
  company_name: string;
}): Promise<V12Response<Session>> {
  return request('POST', '/sessions', { body: JSON.stringify(data) });
}

export async function getSession(sessionId: string): Promise<V12Response<Session & { messages: Message[] }>> {
  return request('GET', `/sessions/${sessionId}`);
}

export async function deleteSession(sessionId: string): Promise<V12Response<void>> {
  return request('DELETE', `/sessions/${sessionId}`);
}

// 3. 公司搜索
export async function searchCompanies(query: string): Promise<V12Response<Company[]>> {
  return request('GET', '/companies/search', { params: { q: query } });
}

// 3.1 公司详情（企业画像）
export async function getCompanyProfile(companyCode: string): Promise<V12Response<CompanyProfile>> {
  return request('GET', `/companies/${companyCode}`);
}

// 4. 财务分析
export async function getFinanceAnalysis(companyCode: string): Promise<V12Response<FinanceRule[]>> {
  return request('GET', `/companies/${companyCode}/finance`);
}

// 5. 舆情事件
export async function getEvents(companyCode: string): Promise<V12Response<{
  clusters: EventCluster[];
  sentiment_summary: SentimentSummary;
  events: TimelineEvent[];
}>> {
  return request('GET', `/companies/${companyCode}/events`);
}

// 6. 风险评估
export async function getRiskAssessment(companyCode: string): Promise<V12Response<RiskAssessment>> {
  return request('GET', `/companies/${companyCode}/risk`);
}

// 7. 行业基准
export async function getIndustryBenchmarks(companyCode: string): Promise<V12Response<IndustryBenchmark[]>> {
  return request('GET', `/companies/${companyCode}/benchmarks`);
}

// 8. 股权穿透
export async function getEquityChain(companyCode: string): Promise<V12Response<EquityData>> {
  return request('GET', `/equity/${companyCode}`);
}

// 9. 证据追溯
export async function getProvenance(evidenceId: string): Promise<V12Response<EvidenceSource>> {
  return request('GET', `/provenance/${evidenceId}`);
}

// 10. 跨公司对比
export async function getComparisons(codes: string[]): Promise<V12Response<ComparisonData>> {
  return request('GET', '/comparisons', { params: { codes: codes.join(',') } });
}

// 11. REST 对话
export async function sendChatMessage(
  sessionId: string,
  content: string,
  companyCode?: string
): Promise<V12Response<ChatResponse>> {
  return request('POST', '/chat', {
    body: JSON.stringify({
      session_id: sessionId,
      message: content,
      company_code: companyCode,
    }),
  });
}

// ---------------------------------------------------------------------------
// WebSocket 对话
// ---------------------------------------------------------------------------

export type WSEventType =
  | 'turn.accepted'
  | 'module.started'
  | 'module.completed'
  | 'answer.delta'
  | 'artifact.upsert'
  | 'turn.completed'
  | 'error';

export interface WSEvent {
  type: WSEventType;
  data: unknown;
  meta?: V12Meta;
}

export interface WSMessage {
  type: 'chat';
  session_id: string;
  message: string;
  company_code?: string;
}

export class TruthNetWebSocket {
  private ws: WebSocket | null = null;
  private url: string;
  private onEvent: (event: WSEvent) => void;
  private onError: (error: Event) => void;
  private onClose: (event: CloseEvent) => void;

  constructor(
    onEvent: (event: WSEvent) => void,
    onError: (error: Event) => void,
    onClose: (event: CloseEvent) => void
  ) {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    this.url = `${protocol}//${host}/api/v1/chat/ws`;
    this.onEvent = onEvent;
    this.onError = onError;
    this.onClose = onClose;
  }

  connect(): void {
    this.ws = new WebSocket(this.url);

    this.ws.onopen = () => {
      console.log('[TruthNet WS] Connected');
    };

    this.ws.onmessage = (event) => {
      try {
        const wsEvent: WSEvent = JSON.parse(event.data);
        this.onEvent(wsEvent);
      } catch (e) {
        console.error('[TruthNet WS] Parse error:', e);
      }
    };

    this.ws.onerror = (error) => {
      console.error('[TruthNet WS] Error:', error);
      this.onError(error);
    };

    this.ws.onclose = (event) => {
      console.log('[TruthNet WS] Closed:', event.code);
      this.onClose(event);
    };
  }

  send(message: WSMessage): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      console.error('[TruthNet WS] Not connected');
    }
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
}

// ---------------------------------------------------------------------------
// 辅助函数
// ---------------------------------------------------------------------------

export function createWebSocket(
  onEvent: (event: WSEvent) => void,
  onError: (error: Event) => void,
  onClose: (event: CloseEvent) => void
): TruthNetWebSocket {
  return new TruthNetWebSocket(onEvent, onError, onClose);
}

// 风险等级颜色映射
export const RISK_COLORS: Record<RiskLevel, string> = {
  red: '#ef4444',
  orange: '#f97316',
  yellow: '#eab308',
  blue: '#3b82f6',
  green: '#22c55e',
};

// 风险等级标签
export const RISK_LABELS: Record<RiskLevel, string> = {
  red: '高危',
  orange: '中高危',
  yellow: '中等',
  blue: '低风险',
  green: '正常',
};

// ---------------------------------------------------------------------------
// 兼容导出 (供旧代码使用)
// ---------------------------------------------------------------------------

// truthnetAPI 导出所有 API 函数
export const truthnetAPI = {
  getSessions,
  createSession,
  getSession,
  deleteSession,
  searchCompanies,
  getFinanceAnalysis,
  getEvents,
  getRiskAssessment,
  getIndustryBenchmarks,
  getEquityChain,
  getProvenance,
  getComparisons,
  sendChatMessage,
};

// apiClient 别名
export const apiClient = truthnetAPI;

// wsClient 别名
export const wsClient = {
  create: createWebSocket,
};

// api 别名 (FinForge 兼容)
export const api = {
  sessions: {
    list: getSessions,
    create: createSession,
    get: getSession,
    delete: deleteSession,
  },
  companies: {
    search: searchCompanies,
  },
  finance: {
    analysis: getFinanceAnalysis,
  },
  events: {
    list: getEvents,
  },
  risk: {
    assessment: getRiskAssessment,
  },
  equity: {
    chain: getEquityChain,
  },
  chat: {
    send: sendChatMessage,
  },
};
