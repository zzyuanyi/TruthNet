// 织网鉴真 TruthNet - 关联方表格组件
// Phase 3: 关联方表 + 图谱联动

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Building2, User, Network, ArrowRight, AlertTriangle } from 'lucide-react';
import type { EquityNodeDTO, EquityEdgeDTO, EquityResponseData } from '@/types/truthnet';
import { cn } from '@/lib/utils';

interface RelatedPartyTableProps {
  equityData: EquityResponseData;
  onNodeClick?: (node: EquityNodeDTO) => void;
  onHighlightPath?: (path: string[]) => void;
}

// 节点类型图标和颜色
const nodeTypeConfig = {
  company: {
    icon: Building2,
    color: 'text-blue-600',
    bgColor: 'bg-blue-500/10',
    label: '公司',
  },
  person: {
    icon: User,
    color: 'text-green-600',
    bgColor: 'bg-green-500/10',
    label: '个人',
  },
  fund: {
    icon: Network,
    color: 'text-purple-600',
    bgColor: 'bg-purple-500/10',
    label: '基金',
  },
};

export function RelatedPartyTable({ equityData, onNodeClick, onHighlightPath }: RelatedPartyTableProps) {
  const { nodes, edges } = equityData;

  // 获取目标公司的直接关联方
  const targetNode = nodes.find(n => n.is_target);
  const relatedNodes = edges
    .filter(l => l.source === targetNode?.id || l.target === targetNode?.id)
    .map(l => {
      const relatedId = l.source === targetNode?.id ? l.target : l.source;
      const relatedNode = nodes.find(n => n.id === relatedId);
      return {
        node: relatedNode,
        link: l,
        isUpstream: l.target === targetNode?.id, // 是否是被投资方
      };
    })
    .filter(r => r.node);

  // 按关系类型分组
  const groupedByRelation = relatedNodes.reduce((groups, item) => {
    const relation = item.link.relation || 'unknown';
    if (!groups[relation]) {
      groups[relation] = [];
    }
    groups[relation].push(item);
    return groups;
  }, {} as Record<string, typeof relatedNodes>);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Network className="h-4 w-4" />
            关联方关系
          </CardTitle>
          <Badge variant="secondary" className="text-xs">
            {nodes.length} 个节点
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        <ScrollArea className="h-[400px]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">关系</TableHead>
                <TableHead>关联方</TableHead>
                <TableHead className="w-[100px]">持股比例</TableHead>
                <TableHead className="w-[80px]">方向</TableHead>
                <TableHead className="w-[80px]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Object.entries(groupedByRelation).map(([relation, items]) => (
                <>
                  <TableRow key={`header-${relation}`} className="bg-muted/50">
                    <TableCell colSpan={5} className="font-medium text-xs py-2">
                      {relationLabels[relation] || relation}
                    </TableCell>
                  </TableRow>
                  {items.map((item, index) => (
                    <RelatedPartyRow
                      key={`${item.node?.id}-${index}`}
                      node={item.node!}
                      link={item.link}
                      isUpstream={item.isUpstream}
                      onNodeClick={onNodeClick}
                      onHighlightPath={onHighlightPath}
                    />
                  ))}
                </>
              ))}
            </TableBody>
          </Table>

          {/* 空状态 */}
          {relatedNodes.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <Network className="h-8 w-8 mb-2" />
              <span className="text-sm">暂无关联方数据</span>
            </div>
          )}
        </ScrollArea>

        {/* 风险提示 */}
        {hasRiskIndicators(equityData) && (
          <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-red-600">
                <div className="font-medium mb-1">风险提示</div>
                <ul className="list-disc list-inside space-y-1">
                  {getRiskIndicators(equityData).map((risk, index) => (
                    <li key={index}>{risk}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// 关联方行组件
interface RelatedPartyRowProps {
  node: EquityNodeDTO;
  link: EquityEdgeDTO;
  isUpstream: boolean;
  onNodeClick?: (node: EquityNodeDTO) => void;
  onHighlightPath?: (path: string[]) => void;
}

function RelatedPartyRow({ node, link, isUpstream, onNodeClick, onHighlightPath }: RelatedPartyRowProps) {
  const typeConfig = nodeTypeConfig[node.type as keyof typeof nodeTypeConfig] || nodeTypeConfig.company;
  const Icon = typeConfig.icon;

  return (
    <TableRow 
      className="group hover:bg-muted/50 cursor-pointer"
      onClick={() => onNodeClick?.(node)}
    >
      <TableCell>
        <Badge variant="outline" className="text-xs">
          {link.relation_type || '投资'}
        </Badge>
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-2">
          <div className={cn('p-1 rounded', typeConfig.bgColor)}>
            <Icon className={cn('h-3 w-3', typeConfig.color)} />
          </div>
          <div>
            <div className="font-medium text-sm">
              {node.name}
            </div>
            {node.code && (
              <div className="text-xs text-muted-foreground">
                {node.code}
              </div>
            )}
          </div>
        </div>
      </TableCell>
      <TableCell>
        <span className="font-mono text-sm">
          {(link.ratio * 100).toFixed(2)}%
        </span>
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          {isUpstream ? (
            <>
              <span>投出</span>
              <ArrowRight className="h-3 w-3" />
            </>
          ) : (
            <>
              <ArrowRight className="h-3 w-3 rotate-180" />
              <span>持有</span>
            </>
          )}
        </div>
      </TableCell>
      <TableCell>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.stopPropagation();
            onHighlightPath?.([link.source, link.target]);
          }}
        >
          定位
        </Button>
      </TableCell>
    </TableRow>
  );
}

// 关系类型标签映射
const relationLabels: Record<string, string> = {
  holding: '控股',
  investment: '投资',
  shareholder: '股东',
  subsidiary: '子公司',
  associate: '联营',
  joint_venture: '合营',
  legal_representative: '法定代表人',
  executive: '高管',
  supervisor: '监事',
  director: '董事',
};

// 检查是否有风险指标
function hasRiskIndicators(equityData: EquityResponseData): boolean {
  const { nodes, edges } = equityData;
  
  // 检查是否有循环持股
  const hasCircular = checkCircularHolding(nodes, edges);
  
  // 检查是否有高比例质押
  const hasHighPledge = edges.some(l => l.pledge_ratio && l.pledge_ratio > 0.5);
  
  // 检查是否有复杂结构（深度 > 3）
  const maxDepth = Math.max(...nodes.map(n => n.depth || 0));
  const hasComplexStructure = maxDepth > 3;
  
  return hasCircular || hasHighPledge || hasComplexStructure;
}

// 获取风险指标列表
function getRiskIndicators(equityData: EquityResponseData): string[] {
  const risks: string[] = [];
  const { nodes, edges } = equityData;
  
  if (checkCircularHolding(nodes, edges)) {
    risks.push('存在循环持股结构，可能存在资本虚增风险');
  }
  
  const highPledgeLinks = edges.filter(l => l.pledge_ratio && l.pledge_ratio > 0.5);
  if (highPledgeLinks.length > 0) {
    risks.push(`${highPledgeLinks.length} 条股权存在高比例质押（>50%）`);
  }
  
  const maxDepth = Math.max(...nodes.map(n => n.depth || 0));
  if (maxDepth > 3) {
    risks.push(`股权结构复杂，穿透深度达 ${maxDepth} 层`);
  }
  
  return risks;
}

// 检查循环持股
function checkCircularHolding(nodes: EquityNodeDTO[], edges: EquityEdgeDTO[]): boolean {
  // 简单的循环检测：检查是否存在 A->B->A 的路径
  const adjacencyList = new Map<string, string[]>();
  
  edges.forEach(link => {
    if (!adjacencyList.has(link.source)) {
      adjacencyList.set(link.source, []);
    }
    adjacencyList.get(link.source)!.push(link.target);
  });
  
  // DFS 检测环
  const visited = new Set<string>();
  const recursionStack = new Set<string>();
  
  function hasCycle(node: string): boolean {
    if (!visited.has(node)) {
      visited.add(node);
      recursionStack.add(node);
      
      const neighbors = adjacencyList.get(node) || [];
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor) && hasCycle(neighbor)) {
          return true;
        }
        if (recursionStack.has(neighbor)) {
          return true;
        }
      }
    }
    recursionStack.delete(node);
    return false;
  }
  
  for (const node of nodes) {
    if (hasCycle(node.id)) {
      return true;
    }
  }
  
  return false;
}
