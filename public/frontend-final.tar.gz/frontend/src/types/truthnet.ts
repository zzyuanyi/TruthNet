// 织网鉴真 TruthNet - 类型定义
// 基于 V12 规范 §11-12
// 对齐后端 API Schema (2026-08-05)

// ============ V12 统一响应格式 ============

export interface V12Meta {
  request_id: string;
  trace_id: string;
  schema_version: string;
  generated_at: string;
  data_as_of: string;
  dataset_version: string;
  rule_set_version: string;
  graph_version: string;
}

export interface V12Warning {
  code: string;
  message: string;
  module?: string;
  recoverable: boolean;
}

export interface V12Response<T> {
  data: T | null;
  meta: V12Meta;
  warnings: V12Warning[];
}

// RFC 9457 ProblemDetail 错误格式
export interface ProblemDetail {
  type: string;
  title: string;
  status: number;
  detail: string;
  instance?: string;
}

// ============ 基础类型 ============

export interface Company {
  code: string;           // 股票代码，如 "600518.SH"
  name: string;           // 公司名称
  industry: string;       // 行业
  market: string;         // 市场
}

export interface Session {
  id: string;
  title: string;
  company_code: string;
  company_name: string;
  created_at: string;
  updated_at: string;
  message_count: number;
  risk_level?: RiskLevel;
}

export interface Message {
  id: string;
  session_id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
  // assistant 消息的额外字段
  thinking?: string;
  structured_data?: PanelData;
  follow_ups?: string[];
  sources?: EvidenceSource[];
  is_streaming?: boolean;
}

// ============ 风险等级 ============

export type RiskLevel = 'red' | 'orange' | 'yellow' | 'blue' | 'green';

export interface RiskLevelInfo {
  level: RiskLevel;
  label: string;
  color: string;
  description: string;
}

export const RISK_LEVELS: Record<RiskLevel, RiskLevelInfo> = {
  red: { level: 'red', label: '高危', color: 'bg-red-500', description: '≥3 条规则触发' },
  orange: { level: 'orange', label: '中高危', color: 'bg-orange-500', description: '研报评级拐点' },
  yellow: { level: 'yellow', label: '中等', color: 'bg-yellow-500', description: '负面公告占比高' },
  blue: { level: 'blue', label: '低风险', color: 'bg-blue-500', description: '指标正常' },
  green: { level: 'green', label: '正常', color: 'bg-green-500', description: '无异常' },
};

// ============ 分析面板数据 ============

export type PanelState = 'empty' | 'loading' | 'ready' | 'thinking' | 'streaming' | 'done' | 'error';

export interface PanelData {
  risk_level: RiskLevel;
  triggered_rules: TriggeredRule[];
  key_metrics: KeyMetric[];
  company?: Company;
}

export interface TriggeredRule {
  id: string;
  name: string;
  current_value: string;
  threshold: string;
  industry_percentile: number;
  severity: 'high' | 'medium' | 'low';
}

export interface KeyMetric {
  name: string;
  value: string;
  change?: string;
  risk_indicator?: RiskLevel;
  industry_benchmark?: string;
}

// ============ 企业画像 ============

export interface CompanyProfile {
  code: string;
  name: string;
  industry: string;
  market: string;
  risk_overview: RiskOverview;
  financial_anomalies: FinancialAnomaly[];
  equity_chain: EquityChain;
  sentiment_events: SentimentEvent[];
  evidence: EvidenceCategory[];
}

export interface RiskOverview {
  risk_level: RiskLevel;
  triggered_rules_count: number;
  negative_announcement_ratio: number;
  summary: string;
}

export interface FinancialAnomaly {
  rule_id: string;
  rule_name: string;
  triggered: boolean;
  current_value: string;
  expected_value: string;
  deviation: string;
  industry_percentile: number;
  explanation: string;
}

export interface EquityChain {
  target_company: string;
  nodes: EquityNode[];
  edges: EquityEdge[];
}

export interface EquityNode {
  id: string;
  name: string;
  type: 'company' | 'person' | 'fund';
  code?: string;
  share_ratio?: number;
  is_target?: boolean;
  depth?: number;
  x?: number;
  y?: number;
}

export interface EquityEdge {
  source: string;
  target: string;
  relation: string;
  ratio?: number;
}

export interface SentimentEvent {
  id: string;
  date: string;
  title: string;
  type: 'positive' | 'negative' | 'neutral';
  source: string;
  impact_score: number;
  summary: string;
}

export interface EvidenceCategory {
  category: string;
  items: EvidenceItem[];
}

export interface EvidenceItem {
  id: string;
  title: string;
  source: string;
  date: string;
  content: string;
  relevance_score: number;
}

export interface EvidenceSource {
  id: string;
  title: string;
  source: string;
  date: string;
  snippet: string;
}

// ============ WebSocket 消息 ============

export type WSMessageType =
  | 'thinking'
  | 'text_chunk'
  | 'structured_data'
  | 'follow_up'
  | 'done'
  | 'error';

export interface WSMessage {
  type: WSMessageType;
  session_id: string;
  payload: unknown;
}

export interface ThinkingPayload {
  step: string;
  progress: number;
}

export interface TextChunkPayload {
  chunk: string;
  is_final: boolean;
}

export interface StructuredDataPayload {
  panel_data: PanelData;
}

export interface FollowUpPayload {
  suggestions: string[];
}

export interface DonePayload {
  message_id: string;
}

export interface ErrorPayload {
  code: string;
  message: string;
}

// ============ 财务规则 (V12) ============

export interface FinanceRule {
  rule_id: string;
  rule_name: string;
  status: 'triggered' | 'not_triggered' | 'insufficient_data' | 'error';
  severity: RiskLevel;
  current: Record<string, { value: number; unit: string }>;
  history: Array<Record<string, number | string>>;
  industry: { p50: number; p75: number; p90: number };
  explanation: string;
  evidence_ids: string[];
}

// ============ 舆情事件 (V12) ============

export interface EventCluster {
  event_cluster_id: string;
  topic: string;
  event_count: number;
  start_date: string;
  end_date: string;
  sentiment: 'positive' | 'negative' | 'neutral' | 'mixed';
  summary: string;
  sources: Array<{
    source_type: string;
    title: string;
    published_at: string;
  }>;
}

export interface SentimentSummary {
  positive_count: number;
  negative_count: number;
  neutral_count: number;
  total_count: number;
  negative_ratio: number;
}

export interface TimelineEvent {
  date: string;
  title: string;
  source_type: string;
  sentiment: string;
  summary: string;
}

// ============ 风险评分 (V12) ============

export interface RiskScore {
  overall: number;
  financial: number;
  ownership: number;
  sentiment: number;
}

export interface RiskAssessment {
  overall_score: number;
  risk_level: RiskLevel;
  sub_scores: Array<{ dimension: string; score: number }>;
  pattern_matches: string[];
  mitigating_factors: string[];
  data_coverage: number;
  evidence: EvidenceSource[];
}

// ============ 行业基准 (V12) ============

export interface IndustryBenchmark {
  metric: string;
  p05: number;
  p25: number;
  p50: number;
  p75: number;
  p95: number;
  company_value: number;
  company_percentile: number;
}

// ============ 跨公司对比 (V12) ============

export interface ComparisonIndicator {
  indicator: string;
  label: string;
  companies: Array<{
    wind_code: string;
    sec_name: string;
    value: number;
    unit: string;
    severity: RiskLevel;
    status: string;
  }>;
}

export interface ComparisonCompany {
  wind_code: string;
  sec_name: string;
  risk_level: RiskLevel;
  overall_score: number;
  triggered_rules: string[];
  pattern_matches: string[];
  coverage: number;
  evidence_ids: string[];
}

export interface ComparisonData {
  period: string;
  indicators: ComparisonIndicator[];
  companies: ComparisonCompany[];
}

// ============ Chat 响应 (V12) ============

// EquityData 类型 (股权穿透数据)
export interface EquityData {
  nodes: EquityNode[];
  edges: EquityEdge[];
}

export interface ChatResponse {
  answer: string;
  evidence: EvidenceSource[];
  graph: EquityData;
  timeline: TimelineEvent[];
  risk_score: RiskScore;
  warnings: V12Warning[];
  missing_modules: string[];
}

// ============ WebSocket 事件 (V12) ============

export type WSEventType =
  | 'turn.accepted'
  | 'module.started'
  | 'module.completed'
  | 'answer.delta'
  | 'artifact.upsert'
  | 'turn.completed'
  | 'error';

export interface WSEvent {
  type: WSEventType;
  data: unknown;
  meta?: V12Meta;
}

// ============ 跨公司对比 (旧版，保留兼容) ============

export interface CompareData {
  companies: Company[];
  metrics: CompareMetric[];
}

export interface CompareMetric {
  name: string;
  values: Record<string, string>; // company_code -> value
  risk_indicators: Record<string, RiskLevel>;
}
